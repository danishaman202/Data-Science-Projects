# -*- coding: utf-8 -*-
"""
Created on Mon May 17 08:29:22 2021

@author: danish
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sb
from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import explained_variance_score
from sklearn.ensemble import RandomForestRegressor
data = pd.read_csv("C:/Users/danish/Documents/handson-ml2-master/datasets/housing/housing.csv")
data['total_bedrooms'].fillna(data['total_bedrooms'].median(),inplace = True) #filled missing values with the mean of housing bedrooms
data.drop(['total_rooms','households'],axis = 1,inplace = True)# dropped these two columns because they both have strong linear coorelatioon with total bedrooms
data['income_cat'] = pd.cut(data['median_income'], bins = [0,1.5,3,4.5,6,np.inf], labels = [1,2,3,4,5])
split = StratifiedShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
for train_index, test_index in split.split(data, data["income_cat"]):
    strat_train_set = data.loc[train_index]
    strat_test_set = data.loc[test_index]
#I did a stratified shuffle split so that these values are not randomly splitted instead they are splitted on basis of income
strat_train_set.drop('income_cat',axis = 1, inplace = True)
strat_test_set.drop('income_cat',axis = 1, inplace = True)
sb.pairplot(strat_train_set,height = 10)#To visualize the relationship among different features
housing = strat_train_set.drop('median_house_value',axis = 1)
housing_label = strat_train_set['median_house_value']

x = pd.get_dummies(housing['ocean_proximity'])
housing = pd.concat([housing,x],axis = 1)
housing.drop('ocean_proximity',axis = 1, inplace = True)
std = StandardScaler()
X_train = std.fit_transform(housing)
housing_test = strat_test_set.drop('median_house_value',axis = 1)
housing_test_label = strat_test_set['median_house_value']

a = pd.get_dummies(housing_test['ocean_proximity'])
housing_test = pd.concat([housing_test,a],axis = 1)
housing_test.drop('ocean_proximity',axis = 1, inplace = True)
X_test = std.transform(housing_test)
model = RandomForestRegressor(n_estimators=150)
model.fit(X_train,housing_label)
y_pred = model.predict(X_test)
print('The resulted variance score is ',explained_variance_score(housing_test_label, y_pred))
